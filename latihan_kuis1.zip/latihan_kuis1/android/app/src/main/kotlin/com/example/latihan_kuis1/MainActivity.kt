package com.example.latihan_kuis1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
